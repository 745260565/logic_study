//
//  YERootViewController.h
//  YYKitExample
//
//  Created by ibireme on 14-10-13.
//  Copyright (c) 2014 ibireme. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YYRootViewController : UITableViewController

@end
