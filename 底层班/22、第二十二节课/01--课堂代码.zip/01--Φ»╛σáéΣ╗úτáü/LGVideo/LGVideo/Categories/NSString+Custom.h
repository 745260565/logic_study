//
//  NSString+Custom.h
//  LGVideo
//
//  Created by LG on 2018/5/20.
//  Copyright © 2018 LG. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Custom)

+ (instancetype)timeformatFromSeconds:(NSTimeInterval)seconds;

@end
