//
//  UIViewController+test.m
//  LGConstructorTest
//
//  Created by LG on 2020/3/20.
//  Copyright © 2020 LG. All rights reserved.
//

#import "UIViewController+test.h"

@implementation UIViewController (test)

+ (void)load{
    NSLog(@"=====%@",self);
}

@end
