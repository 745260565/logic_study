//
//  SceneDelegate.h
//  LGConstructorTest
//
//  Created by LG on 2020/3/20.
//  Copyright © 2020 LG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

