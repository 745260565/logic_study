//
//  ViewController.h
//  LGVideo
//
//  Created by vampire on 2020/3/25.
//  Copyright © 2020 LGEDU. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

