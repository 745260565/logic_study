//
//  ViewController.m
//  LGVideo
//
//  Created by vampire on 2020/3/25.
//  Copyright © 2020 LGEDU. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
