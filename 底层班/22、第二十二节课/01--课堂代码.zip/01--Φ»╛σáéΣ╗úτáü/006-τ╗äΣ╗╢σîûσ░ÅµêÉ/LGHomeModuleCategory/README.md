# LGHomeModuleCategory

[![CI Status](https://img.shields.io/travis/LGCooci/LGHomeModuleCategory.svg?style=flat)](https://travis-ci.org/LGCooci/LGHomeModuleCategory)
[![Version](https://img.shields.io/cocoapods/v/LGHomeModuleCategory.svg?style=flat)](https://cocoapods.org/pods/LGHomeModuleCategory)
[![License](https://img.shields.io/cocoapods/l/LGHomeModuleCategory.svg?style=flat)](https://cocoapods.org/pods/LGHomeModuleCategory)
[![Platform](https://img.shields.io/cocoapods/p/LGHomeModuleCategory.svg?style=flat)](https://cocoapods.org/pods/LGHomeModuleCategory)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

LGHomeModuleCategory is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'LGHomeModuleCategory'
```

## Author

LGCooci, cooci_tz@163.com

## License

LGHomeModuleCategory is available under the MIT license. See the LICENSE file for more info.
