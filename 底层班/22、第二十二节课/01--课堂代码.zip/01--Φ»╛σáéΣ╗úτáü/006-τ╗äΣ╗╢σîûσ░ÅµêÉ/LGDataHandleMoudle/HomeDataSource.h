//
//  HomeDataSource.h
//  LGVideo
//
//  Created by LG on 2018/5/9.
//  Copyright © 2018 LG. All rights reserved.
//

#import "HomeTemplateResponse.h"
#import "LGDataSourceHandleProtocol.h"

@interface HomeDataSource : NSObject<LGDataSourceHandleProtocol>

@end
