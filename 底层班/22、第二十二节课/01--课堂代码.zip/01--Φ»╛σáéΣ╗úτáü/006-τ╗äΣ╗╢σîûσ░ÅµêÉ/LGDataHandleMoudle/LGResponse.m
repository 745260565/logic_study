//
//  LGResponse.m
//  LGVideo
//
//  Created by LG on 04/02/2018.
//  Copyright © 2018 LG. All rights reserved.
//

#import "LGResponse.h"

@implementation LGResponse

@end
