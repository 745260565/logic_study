//
//  HomeTemplateResponse.m
//  LGVideo
//
//  Created by LG on 2018/4/10.
//  Copyright © 2018 LG. All rights reserved.
//

#import "HomeTemplateResponse.h"

@implementation HomeTemplateData
@end

@implementation HomeTemplateItem
@end

@implementation HomeTemplateResponse
@end

@implementation HomeChannelList
@end

@implementation HomeChannelListResponse

@end
