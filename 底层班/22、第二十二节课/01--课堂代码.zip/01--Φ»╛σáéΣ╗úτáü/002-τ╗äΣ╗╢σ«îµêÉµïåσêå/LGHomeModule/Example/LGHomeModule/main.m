//
//  main.m
//  LGHomeModule
//
//  Created by cooci_tz@163.com on 03/23/2020.
//  Copyright (c) 2020 cooci_tz@163.com. All rights reserved.
//

@import UIKit;
#import "LGAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([LGAppDelegate class]));
    }
}
