//
//  LGPlayerResponse.m
//  LGVideo
//
//  Created by LG on 2018/5/27.
//  Copyright © 2018 LG. All rights reserved.
//

#import "LGPlayerResponse.h"

@implementation LGPlayerVideoUrlItem
@end

@implementation LGPlayerVideoUrlResponse
@end
