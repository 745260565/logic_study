//
//  LGPlayerVideoRelativesCell.h
//  LGVideo
//
//  Created by LG on 2018/7/2.
//  Copyright © 2018 LG. All rights reserved.
//

#import "LGTableViewCell.h"

@interface LGPlayerVideoRelativesCell : LGTableViewCell

@end
