//
//  Target_LGPlayerModule.h
//  AFNetworking
//
//  Created by vampire on 2020/3/18.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Target_LGPlayerModule : NSObject

- (UIViewController *)Action_nativeLGPlayerViewController:(NSDictionary * _Nonnull )param;

@end

NS_ASSUME_NONNULL_END
