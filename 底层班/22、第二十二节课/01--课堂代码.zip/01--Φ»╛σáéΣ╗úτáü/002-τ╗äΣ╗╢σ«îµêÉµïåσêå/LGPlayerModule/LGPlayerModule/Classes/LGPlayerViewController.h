//
//  LGPlayerViewController.h
//  LGVideo
//
//  Created by LG on 2018/5/16.
//  Copyright © 2018 LG. All rights reserved.
//

//#import "LGBaseViewController.h"
//#import "HomeTemplateResponse.h"

@interface LGPlayerViewController : UIViewController

//@property (nonatomic, strong) HomeTemplateData *videoInfo;
@property (nonatomic, copy) NSString *videoId;
@property (nonatomic, copy) NSString *videoTitle;

@end
