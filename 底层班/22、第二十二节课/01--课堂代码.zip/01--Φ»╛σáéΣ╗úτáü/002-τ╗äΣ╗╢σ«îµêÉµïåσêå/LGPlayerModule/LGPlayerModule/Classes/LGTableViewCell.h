//
//  LGTableViewCell.h
//  LGVideo
//
//  Created by LG on 24/03/2018.
//  Copyright © 2018 LG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LGTableViewCell : UITableViewCell

- (void)configWithData:(id)data;

@end
