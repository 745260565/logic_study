//
//  UIButton+Custom.h
//  LGVideo
//
//  Created by LG on 2018/7/2.
//  Copyright © 2018 LG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (Custom)

- (void)scaleAnimation;

@end
