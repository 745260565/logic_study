//
//  LGViewController.h
//  LGCommonUIModule
//
//  Created by cooci_tz@163.com on 03/23/2020.
//  Copyright (c) 2020 cooci_tz@163.com. All rights reserved.
//

@import UIKit;

@interface LGViewController : UIViewController

@end
