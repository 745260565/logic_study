//
//  LGAppDelegate.h
//  LGFollowModule
//
//  Created by cooci_tz@163.com on 03/23/2020.
//  Copyright (c) 2020 cooci_tz@163.com. All rights reserved.
//

@import UIKit;

@interface LGAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
