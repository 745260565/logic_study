# LGFollowModule

[![CI Status](https://img.shields.io/travis/cooci_tz@163.com/LGFollowModule.svg?style=flat)](https://travis-ci.org/cooci_tz@163.com/LGFollowModule)
[![Version](https://img.shields.io/cocoapods/v/LGFollowModule.svg?style=flat)](https://cocoapods.org/pods/LGFollowModule)
[![License](https://img.shields.io/cocoapods/l/LGFollowModule.svg?style=flat)](https://cocoapods.org/pods/LGFollowModule)
[![Platform](https://img.shields.io/cocoapods/p/LGFollowModule.svg?style=flat)](https://cocoapods.org/pods/LGFollowModule)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

LGFollowModule is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'LGFollowModule'
```

## Author

cooci_tz@163.com, cooci_tz@163.com

## License

LGFollowModule is available under the MIT license. See the LICENSE file for more info.
