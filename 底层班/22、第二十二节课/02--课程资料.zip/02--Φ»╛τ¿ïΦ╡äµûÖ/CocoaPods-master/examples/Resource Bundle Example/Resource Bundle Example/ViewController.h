//
//  ViewController.h
//  Resource Bundle Example
//
//  Created by Ben Asher on 3/19/16.
//  Copyright © 2016 Example. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

