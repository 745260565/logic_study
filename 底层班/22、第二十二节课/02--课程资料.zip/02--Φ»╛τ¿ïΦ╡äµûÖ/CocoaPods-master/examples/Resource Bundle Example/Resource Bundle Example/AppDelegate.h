//
//  AppDelegate.h
//  Resource Bundle Example
//
//  Created by Ben Asher on 3/19/16.
//  Copyright © 2016 Example. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

