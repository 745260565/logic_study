
#import <Foundation/Foundation.h>

/** Pineapples are cool */
@interface PineappleObj : NSObject
@end
