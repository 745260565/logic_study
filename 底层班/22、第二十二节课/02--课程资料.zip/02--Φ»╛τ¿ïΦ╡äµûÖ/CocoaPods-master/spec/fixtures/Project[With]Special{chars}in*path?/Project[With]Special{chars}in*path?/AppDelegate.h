//
//  AppDelegate.h
//  Project[With]Special{chars}in*path?
//
//  Created by Olivier Halligon on 22/11/2014.
//  Copyright (c) 2014 CocoaPods. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
