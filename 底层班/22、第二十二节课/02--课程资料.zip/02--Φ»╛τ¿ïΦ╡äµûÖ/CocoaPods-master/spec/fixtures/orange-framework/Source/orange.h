#import <UIKit/UIKit.h>

//! Project version number for orange-framework.
FOUNDATION_EXPORT double orangeVersionNumber;

//! Project version string for orange-framework.
FOUNDATION_EXPORT const unsigned char orangeVersionString[];
