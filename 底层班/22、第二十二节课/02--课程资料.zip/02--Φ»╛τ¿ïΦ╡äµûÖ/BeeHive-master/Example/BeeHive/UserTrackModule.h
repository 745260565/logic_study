//
//  UserTrackModule.h
//  BeeHive
//
//  Created by 一渡 on 7/14/15.
//  Copyright (c) 2015 一渡. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UserTrackModule : NSObject

@end
