//
//  ShopModule.h
//  BeeHive
//
//  Created by DP on 16/3/17.
//  Copyright © 2016年 一渡. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ShopModule : NSObject

@end
