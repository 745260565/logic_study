//
//  BHService.h
//  Pods
//
//  Created by 一渡 on 7/16/15.
//
//
#import "BeeHive.h"

#import "HomeServiceProtocol.h"
#import "TradeServiceProtocol.h"
#import "UserTrackServiceProtocol.h"
#import "AppUISkeletonServiceProtocol.h"
#import "AppConfigServiceProtocol.h"
