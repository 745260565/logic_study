//
//  ShopModuleViewController.h
//  BeeHive
//
//  Created by DP on 16/3/28.
//  Copyright © 2016年 一渡. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShopModuleViewController : UIViewController

@property (nonatomic, strong, readonly) UILabel *valueLabel;
@property (nonatomic, strong, readonly) UIImageView *imageView;


@end
