//
//  BHUserTrackViewController.h
//  BeeHive
//
//  Created by 一渡 on 7/14/15.
//  Copyright (c) 2015 一渡. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface BHUserTrackViewController : UIViewController

@end
